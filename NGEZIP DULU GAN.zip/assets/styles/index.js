const Fonts = {
    Nunito: {
        Bold: 'Nunito-Bold',
        Regular:"Nunito-Regular",
        SemiBold:"Nunito-SemiBold",
        BoldItalic:"Nunito-BoldItalic",
        SemiBoldItalic:"Nunito-SemiBoldItalic-",
    }
};
export {Fonts};