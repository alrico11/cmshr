export default {
    "Nunito-Bold": require('./Nunito-Bold.tff'),
    "Nunito-Regular": require('./Nunito-Regular.tff'),
    "Nunito-SemibBold": require('./Nunito-SemibBold.tff'),
    "Nunito-BoldItalic": require('./Nunito-BoldItalic.tff'),
    "Nunito-SemiBoldItalic": require('./Nunito-SemiBoldItalic.tff')
}